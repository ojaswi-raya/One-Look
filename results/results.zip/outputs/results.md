## Comparison of approaches (TEST = Bolivia, Ghana, never seen in training)

| Approach | Precision | Recall | F1 | False-alarm rate | ROC-AUC | Size (KB) | ms / chip (CPU) |
|---|---|---|---|---|---|---|---|
| B1 MNDWI rule (no learning) | 1.00 | 0.23 | 0.38 | 0.00 | 0.78 | 0 | 78.2 |
| M1 Logistic regression | 0.00 | 0.00 | 0.00 | 0.00 | 0.92 | 3 | 78.8 |
| M2 Random forest small (50 trees, depth 6) | 1.00 | 0.40 | 0.57 | 0.00 | 0.94 | 192 | 82.6 |
| M3 Random forest large (300 trees) | 1.00 | 0.40 | 0.57 | 0.00 | 0.94 | 1358 | 107.1 |

Thresholds chosen on validation (Spain, Sri-Lanka) to keep false alarms <= 5%. Final model chosen on validation: **M2 Random forest small (50 trees, depth 6)**. Full bundle (model + UNKNOWN detector): 218 KB, 82.3 ms per chip on CPU (feature extraction 78.2 ms).

## UNKNOWN detection

UNKNOWN if Mahalanobis distance > 159.9 (the 99.0% quantile on train+val).

| Scenes | n | Flagged UNKNOWN | AUROC vs real test chips |
|---|---|---|---|
| real test chips (in-distribution) | 63 | 0% | nan |
| synthetic: thick_cloud | 63 | 100% | 1.000 |
| synthetic: snow | 63 | 100% | 1.000 |
| synthetic: desert_sand | 63 | 100% | 1.000 |
| synthetic: sensor_noise | 63 | 100% | 1.000 |
| synthetic: dead_bands | 63 | 100% | 1.000 |

Synthetic scenes are test chips with simulated conditions, not real imagery.

## Three-way decisions on real test chips

| True \ Decision | ALERT | NO ALERT | UNKNOWN |
|---|---|---|---|
| ALERT | 12 | 18 | 0 |
| NO ALERT | 0 | 33 | 0 |

## Failure cases: 18 wrong test decisions (see failures.csv / failures.png)
